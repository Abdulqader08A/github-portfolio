<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fruit_prijzen = array(
        "appel" => 2.50,
        "banaan" => 1.80,
        "kiwi" => 3.20);

        
        $fruit = $_POST['fruit'];
        $gewicht = $_POST['gewicht'];
        $prijs_per_kg = $fruit_prijzen[$fruit];
        $totaalprijs = ($gewicht / 1000) * $prijs_per_kg; 
    
        echo "De kosten zijn € " . number_format($totaalprijs, 2) . " voor " . $gewicht . " gram " . $fruit . "";
    }
?>