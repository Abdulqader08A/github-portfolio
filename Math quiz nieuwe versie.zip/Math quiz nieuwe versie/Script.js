let correctAnswer;
let streak = 0;
let highestStreak = 0;
let totalAnswers = 0;
let correctAnswers = 0;
let totalScore = 0;
let totalTime = 0;
let fastestTime = Infinity;
let averageTime = 0;
let answerTimes = [];

// Zorg ervoor dat de functie calculateAnswer is gedefinieerd voor het berekenen van het juiste antwoord.
// Mogelijk is afhandeling van gebruikersinvoer en validatie van antwoorden nodig voor een complete toepassing.

function generateQuestion() {
  let num1 = Math.floor(Math.random() * 10) + 1;
  let num2 = Math.floor(Math.random() * 10) + 1;
  const operations = ["+", "-", "*"];
  let operation = operations[Math.floor(Math.random() * operations.length)];

  let questionElement = document.getElementById("question");
  questionElement.textContent =` What is ${num1} ${operation} ${num2}?`;

  correctAnswer = calculateAnswer(num1, num2, operation);

  document.getElementById("btnCheck").disabled = false;
  document.getElementById("answer").value = "";

  startTime = performance.now(); 
}
//fc genaamd calculateAnswer, neemt twee getallen (num1 en num2) en een bewerking (operation) als parameters. 
// Het retourneert het resultaat van de berekening op basis van de opgegeven bewerking.
//Het ondersteunt momenteel de operaties van optellen (+), aftrekken (-), en vermenigvuldigen (*). 
//Als de opgegeven bewerking niet een van deze is, wordt NaN (Not a Number) geretourneerd.
function calculateAnswer(num1, num2, operation) {
  if (operation === "+")
  {
    return num1 + num2;
  } else if (operation === "-")
  {
    return num1 - num2;
  } else if (operation === "*")
  {
    return num1 * num2;
  } else
  {
    return NaN;
  }
}

// Behandelt gebruikersinvoer, geeft visuele feedback op antwoordcorrectheid,
// vereist juiste correctAnswer-initialisatie en aanwezigheid van HTML-klassen.
function checkAnswer() {
  let input = parseInt(document.getElementById("answer").value);

  if (input === correctAnswer)
  {
    document.getElementById("resultIncorrect").classList.remove("resultIncorrect");
    document.getElementById("resultCorrect").classList.add("resultCorrect");


    correctAnswers++; // correctAnswers: Houdt het totale aantal correcte antwoorden bij.
    streak++; //  Vertegenwoordigt de huidige reeks correcte antwoorden.
    totalAnswers++; //  Geeft het totale aantal beantwoorde vragen weer.
//
    totalScore = ((correctAnswers / totalAnswers) * 100).toFixed(2);

    let answerTime = performance.now() - startTime;
    answerTimes.push(answerTime); 
    totalTime += answerTime;
    averageTime = answerTimes.length > 0 ? totalTime / answerTimes.length : 0;
    fastestTime = Math.min(answerTime, fastestTime);

    document.getElementById("feedback").textContent = "Correct!";
  } else
  {
    document.getElementById("resultCorrect").classList.remove("resultCorrect");
    document.getElementById("resultIncorrect").classList.add("resultIncorrect");

    streak = 0;
    totalAnswers++;

    document.getElementById("feedback").textContent = "Incorrect. Try again.";
  }

//Deze regel code actualiseert de hoogste reeks ('highestStreak') door de huidige reeks 
//('streak') te vergelijken en de maximale waarde te behouden.
  highestStreak = Math.max(streak, highestStreak);
// Deze code schakelt de "btnCheck"-knop uit, waardoor deze niet klikbaar is.
  document.getElementById("btnCheck").disabled = true;

  // Deze code berekent de gemiddelde tijd (averageTime) in seconden,
  //of zet deze op 0 als er geen elementen zijn in de array answerTimes.
  averageTime = answerTimes.length > 0 ? totalTime / answerTimes.length / 1000: 0;

 
//Deze code bepaalt de snelste tijd (fastestTime) in seconden,
//of stelt deze in op oneindig (Infinity) als er geen elementen zijn in de array answerTimes.
  fastestTime = answerTimes.length > 0 ? Math.min(...answerTimes) / 1000: Infinity;


  
  let statsElement = document.getElementById("stats");
  statsElement.innerHTML = `
        <p>Current Streak: ${streak}</p>
        <p>Highest Streak: ${highestStreak}</p>
        <p>Total Answers: ${totalAnswers}</p>
        <p>Correct Answers: ${correctAnswers}</p>
        <p>Score: ${totalScore}%</p>
        <p>Average Time: ${averageTime.toFixed(2)} seconds</p>
        <p>Fastest Answer Time: ${fastestTime.toFixed(2)} seconds</p>
        <!-- Add other statistics as needed -->
    `;
}

 
//Deze JavaScript-code wacht tot het HTML-document volledig is geladen (DOMContentLoaded event),
//roept dan de functie generateQuestion() aan, en stelt event listeners in voor de knoppen 
//met de id's "btnCheck" en "btnNext". Als de "btnCheck" wordt geklikt, wordt de functie,
// checkAnswer() uitgevoerd. Als de "btnNext" wordt geklikt 
document.addEventListener("DOMContentLoaded", function () {
  generateQuestion();
  let buttonCheck = document.getElementById("btnCheck");
  buttonCheck.addEventListener("click", checkAnswer);

  let buttonNext = document.getElementById("btnNext");
  buttonNext.addEventListener("click", function () {
    generateQuestion();
  });
});
// Deze code initialiseert de
//variabele startTime met het huidige tijdstip in milliseconden, gemeten met performance.now().
let startTime = performance.now();