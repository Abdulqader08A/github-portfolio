import math
getal1 = int(input("schrijf de eerste getal"))
while (getal1 > 10 or getal1 < 0 ):
    getal1 = int(input("schrijf de eerste getal"))
    
getal2 = int(input("schijf de tweede getal"))
while (getal2 > 10 or getal2 < 0 ):
    getal2 = int(input("schrijf de tweede getal"))
print(f"{getal1} - {getal2} = {getal1 - getal2}")
print(f"{getal1} + {getal2} = {getal1 + getal2}")
print(f"{getal1} x {getal2} = {getal1 * getal2}")
print(f"{getal1} : {getal2} = {getal1 / getal2}")
print(f"U{getal1} = {math.sqrt(getal1)}")
print(f"U{getal2} = {math.sqrt(getal2)}")
print(f"{getal1}^2 = {getal1 ** 2}")
print(f"{getal2}^2 = {getal2 ** 2}")
if getal1 > getal2:
    print(f"{getal1}^{getal2} = {getal1 ** getal2}")
if getal2 > getal1:
    print(f"{getal2}^{getal1} = {getal2 ** getal1}")
if getal1 == getal2:
    print(f"{getal1}^{getal2} = {getal1 ** getal2}")