function loadNotes() {
    let schrijfVakje = document.getElementById("textvakje")
    schrijfVakje.value = localStorage.getItem("text");
}
loadNotes();
let saveButton = document.getElementById("savebutton");
saveButton.addEventListener("click", function() {
    let textVak = document.getElementById("textvakje").value;
    localStorage.setItem("text", textVak);
    console.log("Saved: ", textVak);
});