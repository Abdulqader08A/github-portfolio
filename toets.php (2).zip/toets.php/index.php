<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="sterrenbeeld.php" method="post">
        <label for="geboortedatum">Geboorte datum (dd-mm):</label>
        <input type="text" id="geboortedatum" name="geboortedatum" required pattern="\d{2}-\d{2}">
        <button type="submit">Verzenden</button>
    </form>
</body>
</html>
