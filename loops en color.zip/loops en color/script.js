function generateRandomColor() {
    let r = Math.floor(Math.random() * 256);
    let g = Math.floor(Math.random() * 256);
    let b = Math.floor(Math.random() * 256);
    return 'rgb(' + r + ',' + g + ',' + b + ')';
}

function randomHexColor() {
    const maxColorValueHex = 0xFFFFFF;
    return '#' + Math.floor(Math.random()*maxColorValueHex).toString(16);
}



function generateColorTable(rows, cols) {
    var table = document.createElement('table');

    for (var i = 0; i < rows; i++) {
        var row = table.insertRow();
        for (let j = 0; j < cols; j++) {
            let cell = row.insertCell();
            cell.id = "cellabdul"
            let bgColor = randomHexColor();
            cell.style.backgroundColor = bgColor;
            cell.textContent = bgColor;
            cell.onclick = function() {
                bgColor = cell.style.backgroundColor;
                console.log(bgColor);
                
            };
            let divje = document.createElement("div");
            cell.appendChild(divje);
            divje.id = "cellMax"
            bgColor = randomHexColor();
            divje.style.backgroundColor = bgColor;
            divje.textContent = bgColor;
            divje.onclick = function() {
                bgColor = divje.style.backgroundColor;
                console.log(bgColor);
            };
        }
    }

    document.body.appendChild(table);
}


generateColorTable(4, 4);
