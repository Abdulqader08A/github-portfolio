<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<!DOCTYPE html>
<html>
<head>
    <title>Document</title>
</head>
<body>
    <h2>Kies uw fruit</h2>
    <form action="prijsberekening.php" method="post">
        <h2>Prijzen per kg 
            <p>Appel = 2.50</p>
            <p>Banan = 1.80</p>
            <p>Kiwi = 3.20</p>

        </h2>
        <select name="fruit">
            <option value="appel">Appel</option>
            <option value="banaan">Banaan</option>
            <option value="kiwi">Kiwi</option>
        </select>
        <br><br>
        Hoeveel gram wilt u kopen?
        <input type="text" name="gewicht" required>
        <br><br>
        <input type="submit">
    </form>
</body>
</html>

    
</body>
</html>