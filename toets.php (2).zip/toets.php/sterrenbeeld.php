<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php

$geboortedatum = $_POST['geboortedatum'];
list($month, $day) = explode("-", $geboortedatum);
$geboortedatum_mmdd = sprintf("%02d-%02d", $day, $month);

if ($geboortedatum_mmdd >= '03-21' && $geboortedatum_mmdd <= '04-20') {
    $sterrenbeeld = "Ram";
    $afbeelding = "images/ram.jpg";
}
elseif ($geboortedatum_mmdd >= '04-21' && $geboortedatum_mmdd <= '05-20') {
    $sterrenbeeld = "Stier";
    $afbeelding = "images/stier.jpg";
}elseif ($geboortedatum_mmdd >= '05-21' && $geboortedatum_mmdd <= '06-20') {
    $sterrenbeeld = "Tweelingen";
    $afbeelding = "images/tweelingen.jpg";
}elseif ($geboortedatum_mmdd >= '06-21' && $geboortedatum_mmdd <= '07-20') {
    $sterrenbeeld = "Kreeft";
    $afbeelding = "images/Kreeft.jpg";
} elseif ($geboortedatum_mmdd >= '07-21' && $geboortedatum_mmdd <= '08-20') {
    $sterrenbeeld = "Leeuw";
    $afbeelding = "images/Leeuw.jpg";
} elseif ($geboortedatum_mmdd >= '08-21' && $geboortedatum_mmdd <= '09-20') {
    $sterrenbeeld = "Maagd";
    $afbeelding = "images/Maagd.jpg";
} elseif ($geboortedatum_mmdd >= '09-21' && $geboortedatum_mmdd <= '10-20') {
    $sterrenbeeld = "Weegschaal";
    $afbeelding = "images/Weegschaal.jpg";
} elseif ($geboortedatum_mmdd >= '10-21' && $geboortedatum_mmdd <= '11-20') {
    $sterrenbeeld = "Schorpioen";
    $afbeelding = "images/Schorpioen.jpg";
} elseif ($geboortedatum_mmdd >= '11-21' && $geboortedatum_mmdd <= '12-20') {
    $sterrenbeeld = "Boogschutter";
    $afbeelding = "images/Boogschutter.jpg";
} elseif ($geboortedatum_mmdd >= '12-21' && $geboortedatum_mmdd <= '12-31') {
    $sterrenbeeld = "Steenbok";
    $afbeelding = "images/Steenbok.jpg";
} elseif (($geboortedatum_mmdd >= '01-01' && $geboortedatum_mmdd <= '01-20') || ($geboortedatum_mmdd >= '01-21' && $geboortedatum_mmdd <= '02-20')){
    $sterrenbeeld = "Waterman";
    $afbeelding = "images/Waterman.jpg";
} elseif ($geboortedatum_mmdd >= '02-21' && $geboortedatum_mmdd <= '03-20') {
    $sterrenbeeld = "Vissen";
    $afbeelding = "images/Vissen.jpg";
}

if (isset($sterrenbeeld)) {
    echo "<h2>Je sterrenbeeld is: $sterrenbeeld</h2>";
    echo "<img src='$afbeelding' alt='$sterrenbeeld'>";
}

?>

    <!-- maand = 1 dag <20 steenbok, dag > 20 waterman
        maand = 2 dag < 20 waterman, dag >20 vissen
     -->


    
</body>
</html>