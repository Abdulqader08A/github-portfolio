<?php
    $randomNumber = rand(1, 6);
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<canvas id="mycanvas" width="200" height="200" style="border:1px solid black;"></canvas>
    <script>
 document.addEventListener("DOMContentLoaded", function () {
            let canvas = document.getElementById('mycanvas');
            let context = canvas.getContext('2d');
            let posX = canvas.width / 2;
            let posY = canvas.height / 2;
            let randomNumber = <?php echo $randomNumber; ?>;  

            switch (randomNumber) {
                <?php
                $tekenFuncties = array(
                    1 => "TekenEen",
                    2 => "TekenTwee",
                    3 => "TekenDrie",
                    4 => "TekenVier",
                    5 => "TekenVijf",
                    6 => "TekenZes"
                );
                foreach ($tekenFuncties as $nummer => $functie) {
                    echo "case $nummer:\n";
                    echo "    $functie(context, posX, posY);\n";
                    echo "    break;\n";
                }
                ?>
            }
        });
function TekenEen(context, posX, posY) {
context.beginPath();
context.arc(posX, posY, 10, 0, 10 * Math.PI, false);
context.fill();
        }

function TekenTwee(context, posX, posY) {
context.beginPath();
context.arc(posX - 10, posY - 10, 10, 0, 10 * Math.PI, false);
context.arc(posX + 10, posY + 10, 10, 0, 10 * Math.PI, false);
context.fill();
        }
        function TekenDrie(context, posX, posY) {
context.beginPath();
context.arc(posX - 10, posY - 10, 10, 0, 10 * Math.PI, false);
context.arc(posX + 10, posY + 10, 10, 0, 10 * Math.PI, false);
context.fill();
        }
function TekenVier(context, posX, posY) {
context.beginPath();
context.arc(posX - 10, posY - 10, 10, 0, 10 * Math.PI, false);
context.arc(posX + 10, posY - 10, 10, 0, 10 * Math.PI, false);
context.arc(posX - 10, posY + 10, 10, 0, 10 * Math.PI, false);
context.arc(posX + 10, posY + 10, 10, 0, 10 * Math.PI, false);
context.fill();
        }
function TekenZes(context, posX, posY) {
context.beginPath();
context.arc(posX - 10, posY - 10, 10, 0, 10 * Math.PI, false);
context.arc(posX + 10, posY - 10, 10, 0, 10 * Math.PI, false);
context.arc(posX - 10, posY, 10, 0, 10 * Math.PI, false);
context.arc(posX + 10, posY, 10, 0, 10 * Math.PI, false);
context.arc(posX - 10, posY + 10, 10, 0, 10 * Math.PI, false);
context.arc(posX + 10, posY + 10, 10, 0, 10 * Math.PI, false);
context.fill();
}

</script>

    
</body>
</html>